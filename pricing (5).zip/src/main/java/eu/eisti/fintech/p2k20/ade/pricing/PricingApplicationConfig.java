package eu.eisti.fintech.p2k20.ade.pricing;

public class PricingApplicationConfig {
}
