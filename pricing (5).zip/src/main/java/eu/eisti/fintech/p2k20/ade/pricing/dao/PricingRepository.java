package eu.eisti.fintech.p2k20.ade.pricing.dao;

public class PricingRepository {
}
