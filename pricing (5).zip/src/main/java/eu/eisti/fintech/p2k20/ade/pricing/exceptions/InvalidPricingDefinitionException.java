package eu.eisti.fintech.p2k20.ade.pricing.exceptions;

public class InvalidPricingDefinitionException {
}
