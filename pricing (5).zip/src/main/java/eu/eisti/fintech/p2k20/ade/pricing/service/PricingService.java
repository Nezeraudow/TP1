package eu.eisti.fintech.p2k20.ade.pricing.service;

public class PricingService {
}
