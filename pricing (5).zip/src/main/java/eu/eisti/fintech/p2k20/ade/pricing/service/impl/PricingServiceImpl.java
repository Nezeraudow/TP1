package eu.eisti.fintech.p2k20.ade.pricing.service.impl;

public class PricingServiceImpl {
}
